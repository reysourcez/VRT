// Test harness for Reysourcez-Transcriber-worker_v0.2.js
// Run: node --test test-worker.mjs   (Node 22+)
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';

const SRC = fs.readFileSync(new URL('./Reysourcez-Transcriber-worker_v0.2.js', import.meta.url), 'utf8');
const exposed = SRC + '\nexport const __t = { conf, checkCaps, applyRulesToText, pickEngines, geminiMime, normalizeMime, bytesToBase64, extFor, LANGS, estCost, timingSafeEqual, purgeExpiredAudio };\n';
fs.writeFileSync('/tmp/worker_under_test.mjs', exposed);
const W = await import('/tmp/worker_under_test.mjs?' + Date.now());
const worker = W.default;
const T = W.__t;

/* ---------- mocks ---------- */
class Stmt {
  constructor(db, sql, params) { this.db = db; this.sql = sql; this.params = params || []; }
  bind(...p) {
    for (const v of p) {
      if (v === undefined) throw new Error("D1_TYPE_ERROR: Type 'undefined' not supported for value 'undefined'");
      if (typeof v === 'boolean') throw new Error('D1_TYPE_ERROR: boolean not supported');
    }
    return new Stmt(this.db, this.sql, p);
  }
  async first() { const r = this.db.prepare(this.sql).get(...this.params); return r ? { ...r } : null; }
  async all() { const rows = this.db.prepare(this.sql).all(...this.params); return { results: rows.map((r) => ({ ...r })), success: true, meta: {} }; }
  async run() { const info = this.db.prepare(this.sql).run(...this.params); return { success: true, results: [], meta: { changes: Number(info.changes) } }; }
}
class D1Mock {
  constructor() { this.db = new DatabaseSync(':memory:'); }
  prepare(sql) { return new Stmt(this.db, sql, []); }
  async batch(stmts) {
    const out = [];
    this.db.exec('BEGIN');
    try {
      for (const s of stmts) out.push(/^\s*select/i.test(s.sql) ? await s.all() : await s.run());
      this.db.exec('COMMIT');
    } catch (e) { this.db.exec('ROLLBACK'); throw e; }
    return out;
  }
}
function makeR2() {
  return { store: new Map(), async put(k, v, o) { this.store.set(k, { size: v.byteLength, o }); }, async delete(k) { this.store.delete(k); } };
}
function makeAI(fail) {
  return { calls: [], async run(model, input) { this.calls.push({ model, input }); if (fail) throw new Error(fail); return { text: 'whisper kata hello', transcription_info: { language: 'ms' } }; } };
}

let geminiCalls;
let geminiGenerateStatus = 200;
function installFetch() {
  geminiCalls = [];
  globalThis.fetch = async (url, opts = {}) => {
    const u = String(url);
    const headers = {};
    for (const [k, v] of Object.entries(opts.headers || {})) headers[k.toLowerCase()] = v;
    const rec = { url: u, method: opts.method || 'GET', headers, body: opts.body };
    geminiCalls.push(rec);
    if (u.endsWith('/upload/v1beta/files')) {
      return new Response('{}', { status: 200, headers: { 'x-goog-upload-url': 'https://upload.example/up1' } });
    }
    if (u === 'https://upload.example/up1') {
      return new Response(JSON.stringify({ file: { name: 'files/abc123', uri: 'https://generativelanguage.googleapis.com/v1beta/files/abc123', state: 'ACTIVE' } }), { status: 200 });
    }
    if (u.includes(':generateContent')) {
      if (geminiGenerateStatus !== 200) return new Response(JSON.stringify({ error: { message: 'boom', status: 'INTERNAL' } }), { status: geminiGenerateStatus });
      return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: 'selamat pagi semua teh' }] } }] }), { status: 200 });
    }
    if ((opts.method || '') === 'DELETE') return new Response('{}', { status: 200 });
    return new Response('not mocked: ' + u, { status: 599 });
  };
}

function makeEnv(extra) {
  return Object.assign({
    DB: new D1Mock(), AI: makeAI(), AUDIO: makeR2(),
    ACCESS_CODE: 'secret-code', ADMIN_CODE: 'admin-code', GEMINI_API_KEY: 'gkey', GEMINI_ENABLED: '1'
  }, extra || {});
}
function makeCtx() { const pending = []; return { pending, waitUntil(p) { pending.push(p); } }; }

async function call(env, ctx, path, o = {}) {
  const headers = Object.assign({ Origin: 'https://www.reysourcez.com', 'X-RZ-Access': 'secret-code', 'X-RZ-Client': 'client-test-0001' }, o.headers || {});
  let body = o.body;
  if (body && typeof body === 'object' && !(body instanceof Uint8Array) && !(body instanceof ArrayBuffer)) { body = JSON.stringify(body); headers['Content-Type'] = headers['Content-Type'] || 'application/json'; }
  const req = new Request('https://worker.example' + path, { method: o.method || 'GET', headers, body });
  const res = await worker.fetch(req, env, ctx);
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch (e) { data = text; }
  return { status: res.status, data, headers: res.headers };
}
const audio = (n) => new Uint8Array(n || 3000).fill(7);
async function consent(env, ctx, extra) {
  return call(env, ctx, '/api/consent', { method: 'POST', body: Object.assign({ version: '2026-10-v1', processing: true, participants: true, keepAudio: false }, extra || {}) });
}
const tq = (o) => '/api/transcribe?' + new URLSearchParams(Object.assign({ rid: 'rec-aaaaaaaa', idx: '0', lang: 'ms', dur: '60', src: 'mic' }, o || {})).toString();

/* ---------- pure functions ---------- */
test('conf: defaults and overrides', () => {
  const c = T.conf({ MONTHLY_CAP_USD: '9', GEMINI_ENABLED: ' ' });
  assert.equal(c.MONTHLY_CAP_USD, '9');
  assert.equal(c.GEMINI_ENABLED, '0');
  assert.equal(c.CONSENT_VERSION, '2026-10-v1');
});

test('checkCaps: monthly, daily, ok', () => {
  const base = { monthCostUsd: 4.9, addCostUsd: 0.2, capUsd: 5, clientSecsToday: 0, addSecs: 60, dailyMin: 120 };
  assert.equal(T.checkCaps(base).code, 'monthly_cap');
  assert.equal(T.checkCaps({ ...base, addCostUsd: 0.05 }).ok, true);
  assert.equal(T.checkCaps({ ...base, monthCostUsd: 0, clientSecsToday: 7190, addSecs: 60 }).code, 'daily_cap');
  assert.equal(T.checkCaps({ ...base, monthCostUsd: 0, clientSecsToday: 7140, addSecs: 60 }).ok, true);
});

test('applyRulesToText: whole words only, keeps capital, unicode safe', () => {
  const rules = [{ wrong: 'teh', right: 'the' }, { wrong: 'kuching baru', right: 'Kuching Baru' }];
  assert.equal(T.applyRulesToText('teh cat. Teh dog. tehran stays. steh stays.', rules), 'the cat. The dog. tehran stays. steh stays.');
  assert.equal(T.applyRulesToText('di kuching baru hari ini', rules), 'di Kuching Baru hari ini');
  assert.equal(T.applyRulesToText('a.b (x)', [{ wrong: 'a.b', right: 'c' }]), 'c (x)');
  assert.equal(T.applyRulesToText('', rules), '');
  assert.equal(T.applyRulesToText('\u4f60\u597d\u5417 \u670b\u53cb', [{ wrong: '\u4f60\u597d', right: '\u60a8\u597d' }]), '\u60a8\u597d\u5417 \u670b\u53cb');
  assert.equal(T.applyRulesToText('abc', null), 'abc');
});

test('pickEngines: language and availability', () => {
  const both = { gemini: true, whisper: true };
  assert.deepEqual(T.pickEngines(both, T.LANGS.ms, 'auto'), { engines: ['gemini'], fallback: 'whisper' });
  assert.deepEqual(T.pickEngines(both, T.LANGS.ta, 'auto'), { engines: ['whisper'], fallback: null });
  assert.deepEqual(T.pickEngines(both, T.LANGS.ta, 'gemini'), { engines: [], fallback: null });
  assert.deepEqual(T.pickEngines(both, T.LANGS.ms, 'both'), { engines: ['gemini', 'whisper'], fallback: null });
  assert.deepEqual(T.pickEngines({ gemini: false, whisper: true }, T.LANGS.ms, 'auto'), { engines: ['whisper'], fallback: null });
  assert.deepEqual(T.pickEngines({ gemini: false, whisper: false }, T.LANGS.ms, 'auto'), { engines: [], fallback: null });
});

test('mime helpers', () => {
  assert.equal(T.normalizeMime('audio/webm;codecs=opus'), 'audio/webm');
  assert.equal(T.geminiMime('audio/webm'), 'audio/webm');
  assert.equal(T.geminiMime('audio/mp4'), 'audio/m4a');
  assert.equal(T.geminiMime('image/png'), null);
  assert.equal(T.extFor('audio/mp4'), 'm4a');
  assert.equal(T.extFor('audio/webm'), 'webm');
});

test('bytesToBase64 matches Buffer (100 KB random)', () => {
  const b = new Uint8Array(100003);
  for (let i = 0; i < b.length; i++) b[i] = (i * 31 + 7) & 255;
  assert.equal(T.bytesToBase64(b), Buffer.from(b).toString('base64'));
});

test('estCost uses configured rates', () => {
  const c = T.conf({});
  assert.ok(Math.abs(T.estCost(c, 'gemini', 3600) - 0.3) < 1e-9);
  assert.ok(Math.abs(T.estCost(c, 'whisper', 3600) - 0.0306) < 1e-6);
});

/* ---------- HTTP flow ---------- */
test('CORS: allowed origin echoed, other origin not', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  const ok = await worker.fetch(new Request('https://worker.example/api/config', { method: 'OPTIONS', headers: { Origin: 'https://www.reysourcez.com' } }), env, ctx);
  assert.equal(ok.status, 204);
  assert.equal(ok.headers.get('Access-Control-Allow-Origin'), 'https://www.reysourcez.com');
  const bad = await worker.fetch(new Request('https://worker.example/api/config', { method: 'OPTIONS', headers: { Origin: 'https://evil.example' } }), env, ctx);
  assert.equal(bad.headers.get('Access-Control-Allow-Origin'), null);
});

test('health: public, reports problems in plain language', async () => {
  installFetch();
  const ctx = makeCtx();
  const r1 = await call(makeEnv({ ACCESS_CODE: undefined }), ctx, '/api/health', { headers: { 'X-RZ-Access': '' } });
  assert.equal(r1.status, 200);
  assert.equal(r1.data.ok, false);
  assert.ok(r1.data.hints.some((h) => /ACCESS_CODE/.test(h)));
  const r2 = await call(makeEnv(), ctx, '/api/health');
  assert.equal(r2.data.ok, true);
  assert.equal(r2.data.checks.db, true);
  assert.equal(r2.data.checks.schemaVersion, 1);
  assert.equal(r2.data.checks.geminiEnabled, true);
  const r3 = await call(makeEnv({ DB: undefined }), ctx, '/api/health');
  assert.equal(r3.data.ok, false);
  assert.ok(r3.data.hints.some((h) => /D1 binding/.test(h)));
});

test('auth: missing/wrong code, lockout after 20 wrong tries, client id check', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  assert.equal((await call(env, ctx, '/api/config', { headers: { 'X-RZ-Access': '' } })).status, 401);
  for (let i = 0; i < 19; i++) await call(env, ctx, '/api/config', { headers: { 'X-RZ-Access': 'nope' + i } });
  const locked = await call(env, ctx, '/api/config', { headers: { 'X-RZ-Access': 'secret-code' } });
  assert.equal(locked.status, 429, 'after 20 wrong guesses even the right code is blocked for the hour');
  const env2 = makeEnv();
  assert.equal((await call(env2, ctx, '/api/config', { headers: { 'X-RZ-Client': 'x' } })).status, 400);
  assert.equal((await call(env2, ctx, '/api/config')).status, 200);
  const nocode = await call(makeEnv({ ACCESS_CODE: undefined }), ctx, '/api/config');
  assert.equal(nocode.status, 503);
});

test('config: languages, engines, limits', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  const r = await call(env, ctx, '/api/config');
  assert.equal(r.status, 200);
  assert.equal(r.data.version, '0.2');
  assert.equal(r.data.engines.gemini, true);
  assert.equal(r.data.engines.r2, true);
  const ta = r.data.languages.find((l) => l.id === 'ta');
  assert.equal(ta.geminiOk, false);
  assert.equal(ta.whisperOk, true);
  assert.equal(r.data.limits.monthlyCapUsd, 5);
});

test('transcribe needs consent; then Gemini path sends the documented request', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  const no = await call(env, ctx, tq(), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm;codecs=opus' } });
  assert.equal(no.status, 403);
  assert.equal(no.data.error, 'consent_required');
  assert.equal((await consent(env, ctx)).status, 200);
  // add a lexicon term so customVocabulary is sent
  await call(env, ctx, '/api/lexicon', { method: 'POST', body: { items: [{ language: 'ms', term: 'Kuching', meaning: 'city' }] } });
  geminiCalls.length = 0;
  const r = await call(env, ctx, tq(), { method: 'POST', body: audio(3000), headers: { 'Content-Type': 'audio/webm;codecs=opus' } });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.primary, 'gemini');
  assert.equal(r.data.text, 'selamat pagi semua teh');
  assert.equal(r.data.cached, false);
  await Promise.all(ctx.pending);
  const start = geminiCalls.find((c) => c.url.endsWith('/upload/v1beta/files'));
  assert.equal(start.headers['x-goog-api-key'], 'gkey');
  assert.equal(start.headers['x-goog-upload-protocol'], 'resumable');
  assert.equal(start.headers['x-goog-upload-command'], 'start');
  assert.equal(start.headers['x-goog-upload-header-content-length'], '3000');
  assert.equal(start.headers['x-goog-upload-header-content-type'], 'audio/webm');
  const fin = geminiCalls.find((c) => c.url === 'https://upload.example/up1');
  assert.equal(fin.headers['x-goog-upload-command'], 'upload, finalize');
  assert.equal(fin.headers['x-goog-upload-offset'], '0');
  assert.equal(fin.body.byteLength, 3000);
  const gen = geminiCalls.find((c) => c.url.includes(':generateContent'));
  assert.ok(gen.url.includes('/v1beta/models/gemini-3.5-transcribe:generateContent'));
  const gb = JSON.parse(gen.body);
  assert.deepEqual(gb.contents[0].parts[0].fileData, { fileUri: 'https://generativelanguage.googleapis.com/v1beta/files/abc123', mimeType: 'audio/webm' });
  assert.deepEqual(gb.generationConfig.audioTranscriptionConfig.languageCodes, ['ms-MY']);
  assert.deepEqual(gb.generationConfig.audioTranscriptionConfig.customVocabulary, ['Kuching']);
  assert.equal(gb.generationConfig.audioTranscriptionConfig.mode, undefined);
  const del = geminiCalls.find((c) => c.method === 'DELETE');
  assert.ok(del && del.url.endsWith('/v1beta/files/abc123'), 'uploaded file is deleted after use');
  // usage saved
  const u = await call(env, ctx, '/api/usage');
  assert.ok(u.data.device.minutesToday >= 1);
  assert.ok(u.data.site.costMonthUsd > 0);
});

test('transcribe: m4a is sent to Gemini as audio/m4a; smart mode; auto language sends empty codes', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  geminiCalls.length = 0;
  const r = await call(env, ctx, tq({ lang: 'auto', mode: 'smart', rid: 'rec-bbbbbbbb' }), { method: 'POST', body: audio(2000), headers: { 'Content-Type': 'audio/mp4' } });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  const gen = geminiCalls.find((c) => c.url.includes(':generateContent'));
  const gb = JSON.parse(gen.body);
  assert.equal(gb.contents[0].parts[0].fileData.mimeType, 'audio/m4a');
  assert.deepEqual(gb.generationConfig.audioTranscriptionConfig.languageCodes, []);
  assert.equal(gb.generationConfig.audioTranscriptionConfig.mode, 'SMART');
});

test('retry of the same part is cached (no second charge); force re-runs', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  const h = { 'Content-Type': 'audio/webm' };
  await call(env, ctx, tq({ rid: 'rec-cccccccc' }), { method: 'POST', body: audio(), headers: h });
  const n1 = geminiCalls.length;
  const again = await call(env, ctx, tq({ rid: 'rec-cccccccc' }), { method: 'POST', body: audio(), headers: h });
  assert.equal(again.data.cached, true);
  assert.equal(geminiCalls.length, n1, 'no engine call on a cached retry');
  const forced = await call(env, ctx, tq({ rid: 'rec-cccccccc', force: '1' }), { method: 'POST', body: audio(), headers: h });
  assert.equal(forced.data.cached, false);
  assert.ok(geminiCalls.length > n1);
  const usage = await call(env, ctx, '/api/usage');
  assert.ok(usage.data.device.minutesToday >= 2 - 1e-9 && usage.data.device.minutesToday < 2.01, 'two real runs counted (2 x 60 s)');
});

test('compare mode runs both engines and stores both', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  const r = await call(env, ctx, tq({ engine: 'both', rid: 'rec-dddddddd' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.results.length, 2);
  assert.deepEqual(r.data.results.map((x) => x.engine).sort(), ['gemini', 'whisper']);
  assert.ok(env.AI.calls.length === 1);
  const input = env.AI.calls[0].input;
  assert.equal(env.AI.calls[0].model, '@cf/openai/whisper-large-v3-turbo');
  assert.equal(input.language, 'ms');
  assert.equal(input.task, 'transcribe');
  assert.equal(input.vad_filter, true);
  assert.equal(Buffer.from(input.audio, 'base64').length, 3000);
  const detail = await call(env, ctx, '/api/recordings/rec-dddddddd');
  assert.equal(detail.data.segments[0].runs.length, 2);
  // score both
  const seg = detail.data.segments[0].id;
  const sc = await call(env, ctx, '/api/score', { method: 'POST', body: { segmentId: seg, scores: { gemini: { wer: 0.1, refWords: 40 }, whisper: { wer: 0.25, refWords: 40 }, bogus: { wer: 1, refWords: 1 } } } });
  assert.equal(sc.data.saved, 2);
  const detail2 = await call(env, ctx, '/api/recordings/rec-dddddddd');
  const wers = Object.fromEntries(detail2.data.segments[0].runs.map((x) => [x.engine, x.wer]));
  assert.equal(wers.gemini, 0.1);
  assert.equal(wers.whisper, 0.25);
});

test('Tamil goes to Whisper only; lexicon terms become initial_prompt', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  await call(env, ctx, '/api/lexicon', { method: 'POST', body: { items: [{ language: 'ta', term: 'vanakkam' }, { language: 'ta', term: 'nandri' }] } });
  geminiCalls.length = 0;
  const r = await call(env, ctx, tq({ lang: 'ta', rid: 'rec-eeeeeeee' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.primary, 'whisper');
  assert.equal(geminiCalls.length, 0);
  assert.equal(env.AI.calls[0].input.language, 'ta');
  assert.match(env.AI.calls[0].input.initial_prompt, /vanakkam/);
  const g = await call(env, ctx, tq({ lang: 'ta', engine: 'gemini', rid: 'rec-eeeeeeef' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  assert.equal(g.status, 400);
  assert.equal(g.data.error, 'no_engine');
});

test('auto: Gemini fails -> falls back to Whisper, both runs recorded', async () => {
  installFetch();
  geminiGenerateStatus = 500;
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  const r = await call(env, ctx, tq({ rid: 'rec-ffffffff' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  geminiGenerateStatus = 200;
  assert.equal(r.status, 200, JSON.stringify(r.data));
  assert.equal(r.data.primary, 'whisper');
  assert.equal(r.data.results.length, 2);
  assert.equal(r.data.results[0].ok, false);
  assert.match(r.data.results[0].error, /temporarily unavailable/);
});

test('all engines fail -> 502 with plain message, error logged, nothing charged', async () => {
  installFetch();
  geminiGenerateStatus = 500;
  const env = makeEnv({ AI: makeAI('decode error: invalid data') }); const ctx = makeCtx();
  await consent(env, ctx);
  const r = await call(env, ctx, tq({ rid: 'rec-gggggggg' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  geminiGenerateStatus = 200;
  assert.equal(r.status, 502);
  assert.equal(r.data.error, 'engine_failed');
  assert.ok(Array.isArray(r.data.results));
  const u = await call(env, ctx, '/api/usage');
  assert.equal(u.data.site.costMonthUsd, 0);
  const rows = env.DB.db.prepare('SELECT COUNT(*) AS n FROM error_log').get();
  assert.ok(rows.n >= 1);
});

test('no engines configured gives a clear message', async () => {
  installFetch();
  const env = makeEnv({ GEMINI_ENABLED: '0', AI: undefined }); const ctx = makeCtx();
  await consent(env, ctx);
  const r = await call(env, ctx, tq(), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  assert.equal(r.status, 400);
  assert.match(r.data.message, /Gemini is off/);
  assert.match(r.data.message, /Whisper is off/);
});

test('input checks: empty, too large, wrong type, too long', async () => {
  installFetch();
  const env = makeEnv({ MAX_UPLOAD_MB: '1' }); const ctx = makeCtx();
  await consent(env, ctx);
  const h = { 'Content-Type': 'audio/webm' };
  assert.equal((await call(env, ctx, tq(), { method: 'POST', body: new Uint8Array(0), headers: h })).data.error, 'empty_audio');
  assert.equal((await call(env, ctx, tq(), { method: 'POST', body: new Uint8Array(1.5 * 1024 * 1024), headers: h })).status, 413);
  assert.equal((await call(env, ctx, tq(), { method: 'POST', body: audio(), headers: { 'Content-Type': 'image/png' } })).status, 415);
  assert.equal((await call(env, ctx, tq({ dur: '99999' }), { method: 'POST', body: audio(), headers: h })).status, 413);
});

test('caps: monthly cost and daily minutes are enforced before any engine call', async () => {
  installFetch();
  const ctx = makeCtx();
  const e1 = makeEnv({ MONTHLY_CAP_USD: '0.001' });
  await consent(e1, ctx);
  geminiCalls.length = 0;
  const r1 = await call(e1, ctx, tq({ dur: '600' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  assert.equal(r1.status, 429);
  assert.equal(r1.data.error, 'monthly_cap');
  assert.equal(geminiCalls.length, 0);
  const e2 = makeEnv({ DAILY_MIN_PER_CLIENT: '0.5' });
  await consent(e2, ctx);
  const r2 = await call(e2, ctx, tq({ dur: '60' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  assert.equal(r2.data.error, 'daily_cap');
});

test('byte size cannot be hidden by a tiny dur value', async () => {
  installFetch();
  const env = makeEnv({ DAILY_MIN_PER_CLIENT: '1' }); const ctx = makeCtx();
  await consent(env, ctx);
  // 8 MB at the 40,000 B/s floor is 200 s, over 1 minute, even though dur=1
  const r = await call(env, ctx, tq({ dur: '1' }), { method: 'POST', body: new Uint8Array(8 * 1024 * 1024), headers: { 'Content-Type': 'audio/webm' } });
  assert.equal(r.data.error, 'daily_cap');
});

test('corrections: fix suggested at 3 sightings; admin approves; rule then applied', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  const h = { 'Content-Type': 'audio/webm' };
  const t = await call(env, ctx, tq({ rid: 'rec-hhhhhhhh' }), { method: 'POST', body: audio(), headers: h });
  const seg = t.data.segmentId;
  let last;
  for (let i = 0; i < 3; i++) {
    last = await call(env, ctx, '/api/corrections', { method: 'POST', body: { segmentId: seg, after: 'selamat pagi semua the v' + i, pairs: [{ w: 'teh', r: 'the' }], newWords: ['Kuching', 'ab'] } });
    assert.equal(last.status, 200, JSON.stringify(last.data));
  }
  assert.equal(last.data.suggestions.rules.length, 1);
  assert.equal(last.data.suggestions.rules[0].seen, 3);
  assert.deepEqual(last.data.suggestions.newWords, ['Kuching']);
  const ruleId = last.data.suggestions.rules[0].id;
  const sug = await call(env, ctx, '/api/rules');
  assert.equal(sug.data.rules.length, 1);
  const denied = await call(env, ctx, '/api/rules/' + ruleId + '/approve', { method: 'POST' });
  assert.equal(denied.status, 403);
  const ok = await call(env, ctx, '/api/rules/' + ruleId + '/approve', { method: 'POST', headers: { 'X-RZ-Admin': 'admin-code' } });
  assert.equal(ok.status, 200);
  const t2 = await call(env, ctx, tq({ rid: 'rec-iiiiiiii' }), { method: 'POST', body: audio(), headers: h });
  assert.equal(t2.data.text, 'selamat pagi semua the', 'approved rule replaced "teh" in the engine text');
  const approved = await call(env, ctx, '/api/rules?status=approved');
  assert.equal(approved.data.rules.length, 1);
  // unchanged text => changed:false
  const same = await call(env, ctx, '/api/corrections', { method: 'POST', body: { segmentId: seg, after: 'selamat pagi semua the v2' } });
  assert.equal(same.data.changed, false);
});

test('corrections: other device cannot touch my part', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  const t = await call(env, ctx, tq({ rid: 'rec-jjjjjjjj' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  const other = { 'X-RZ-Client': 'client-other-0002' };
  const r = await call(env, ctx, '/api/corrections', { method: 'POST', headers: other, body: { segmentId: t.data.segmentId, after: 'x' } });
  assert.equal(r.status, 403);
  const rec = await call(env, ctx, '/api/recordings/rec-jjjjjjjj', { headers: other });
  assert.equal(rec.status, 403);
  const list = await call(env, ctx, '/api/recordings', { headers: other });
  assert.equal(list.data.recordings.length, 0);
});

test('lexicon: add, merge, list, filter, admin-only change/delete, bad language skipped', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  const add = await call(env, ctx, '/api/lexicon', { method: 'POST', body: { items: [
    { language: 'ms-sarawak', term: 'TERM_A', meaning: 'one' }, { language: 'ms-sarawak', term: 'TERM_A', variants: 'v1' },
    { language: 'xx', term: 'bad' }, { language: 'iban', term: '' }, { language: 'iban', term: 'TERM_B' }] } });
  assert.equal(add.data.saved, 3);
  assert.equal(add.data.skipped, 2);
  const list = await call(env, ctx, '/api/lexicon?lang=ms-sarawak');
  assert.equal(list.data.terms.length, 1);
  assert.equal(list.data.terms[0].meaning, 'one');
  assert.equal(list.data.terms[0].variants, 'v1');
  assert.equal(list.data.terms[0].status, 'unverified');
  const q = await call(env, ctx, '/api/lexicon?q=term_b');
  assert.equal(q.data.terms.length, 1);
  const id = list.data.terms[0].id;
  assert.equal((await call(env, ctx, '/api/lexicon/' + id, { method: 'PATCH', body: { status: 'verified' } })).status, 403);
  assert.equal((await call(env, ctx, '/api/lexicon/' + id, { method: 'PATCH', body: { status: 'verified' }, headers: { 'X-RZ-Admin': 'admin-code' } })).status, 200);
  assert.equal((await call(env, ctx, '/api/lexicon/' + id, { method: 'PATCH', body: { status: 'nope' }, headers: { 'X-RZ-Admin': 'admin-code' } })).status, 400);
  assert.equal((await call(env, ctx, '/api/lexicon/' + id, { method: 'DELETE', headers: { 'X-RZ-Admin': 'admin-code' } })).status, 200);
  assert.equal((await call(env, ctx, '/api/lexicon?lang=ms-sarawak')).data.terms.length, 0);
});

test('lexicon import of 120 rows (batches of 50) and verified terms are sent first', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  const items = Array.from({ length: 120 }, (_, i) => ({ language: 'ms-sarawak', term: 'TERM_' + String(i).padStart(3, '0') }));
  const r = await call(env, ctx, '/api/lexicon', { method: 'POST', body: { items } });
  assert.equal(r.data.saved, 120);
  const list = await call(env, ctx, '/api/lexicon?lang=ms-sarawak&limit=500');
  const pick = list.data.terms.find((x) => x.term === 'TERM_119');
  await call(env, ctx, '/api/lexicon/' + pick.id, { method: 'PATCH', body: { status: 'verified' }, headers: { 'X-RZ-Admin': 'admin-code' } });
  geminiCalls.length = 0;
  await call(env, ctx, tq({ lang: 'ms-sarawak', rid: 'rec-kkkkkkkk' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  const gen = geminiCalls.find((c) => c.url.includes(':generateContent'));
  const vocab = JSON.parse(gen.body).generationConfig.audioTranscriptionConfig.customVocabulary;
  assert.equal(vocab.length, 100, 'capped at BIAS_TERMS_MAX');
  assert.equal(vocab[0], 'TERM_119', 'verified term first');
});

test('keep audio: needs R2 + consent; delete removes R2 object and rows', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx, { keepAudio: false });
  const h = { 'Content-Type': 'audio/webm' };
  const no = await call(env, ctx, tq({ keep: '1', rid: 'rec-llllllll' }), { method: 'POST', body: audio(), headers: h });
  assert.equal(env.AUDIO.store.size, 0);
  assert.match(no.data.notes.join(' '), /keep-audio consent is off/);
  await consent(env, ctx, { keepAudio: true });
  const yes = await call(env, ctx, tq({ keep: '1', rid: 'rec-mmmmmmmm' }), { method: 'POST', body: audio(), headers: h });
  assert.equal(env.AUDIO.store.size, 1);
  const key = [...env.AUDIO.store.keys()][0];
  assert.match(key, /^audio\/\d{4}-\d{2}\/rec-mmmmmmmm\/0\.webm$/);
  assert.equal(yes.data.notes.length, 0);
  const del = await call(env, ctx, '/api/recordings/rec-mmmmmmmm', { method: 'DELETE' });
  assert.equal(del.data.deleted, true);
  assert.equal(env.AUDIO.store.size, 0);
  assert.equal((await call(env, ctx, '/api/recordings/rec-mmmmmmmm')).status, 404);
  const noR2 = makeEnv({ AUDIO: undefined }); await consent(noR2, ctx, { keepAudio: true });
  const r = await call(noR2, ctx, tq({ keep: '1', rid: 'rec-nnnnnnnn' }), { method: 'POST', body: audio(), headers: h });
  assert.match(r.data.notes.join(' '), /no R2 storage/);
});

test('purge job removes audio older than retention', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx, { keepAudio: true });
  await call(env, ctx, tq({ keep: '1', rid: 'rec-oooooooo' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  env.DB.db.exec("UPDATE segments SET created_at='2020-01-01T00:00:00.000Z'");
  assert.equal(env.AUDIO.store.size, 1);
  await T.purgeExpiredAudio(env);
  assert.equal(env.AUDIO.store.size, 0);
  assert.equal(env.DB.db.prepare('SELECT COUNT(*) AS n FROM segments WHERE r2_key IS NOT NULL').get().n, 0);
});

test('recordings: list, rename, detail', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  const h = { 'Content-Type': 'audio/webm' };
  await call(env, ctx, tq({ rid: 'rec-pppppppp', idx: '0', title: 'Weekly meeting' }), { method: 'POST', body: audio(), headers: h });
  await call(env, ctx, tq({ rid: 'rec-pppppppp', idx: '1' }), { method: 'POST', body: audio(), headers: h });
  const l = await call(env, ctx, '/api/recordings');
  assert.equal(l.data.recordings.length, 1);
  assert.equal(l.data.recordings[0].parts, 2);
  assert.equal(l.data.recordings[0].title, 'Weekly meeting');
  await call(env, ctx, '/api/recordings/rec-pppppppp', { method: 'PATCH', body: { title: 'Renamed' } });
  const d = await call(env, ctx, '/api/recordings/rec-pppppppp');
  assert.equal(d.data.recording.title, 'Renamed');
  assert.deepEqual(d.data.segments.map((s) => s.idx), [0, 1]);
});

test('errors: unknown route 404, bad JSON 400, consent wrong version 409', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  assert.equal((await call(env, ctx, '/api/nothing')).status, 404);
  assert.equal((await call(env, ctx, '/elsewhere')).status, 404);
  const bad = new Request('https://worker.example/api/consent', { method: 'POST', headers: { 'X-RZ-Access': 'secret-code', 'X-RZ-Client': 'client-test-0001' }, body: '{oops' });
  const br = await worker.fetch(bad, env, ctx);
  assert.equal(br.status, 400);
  assert.equal((await call(env, ctx, '/api/consent', { method: 'POST', body: { version: 'old', processing: true, participants: true } })).status, 409);
  const root = await worker.fetch(new Request('https://worker.example/'), env, ctx);
  assert.equal(root.status, 200);
  assert.match(await root.text(), /v0\.2/);
});

test('client log endpoint stores a short row', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  const r = await call(env, ctx, '/api/log', { method: 'POST', body: { code: 'mic_denied', message: 'x'.repeat(900), detail: 'y' } });
  assert.equal(r.status, 200);
  const row = env.DB.db.prepare('SELECT message FROM error_log').get();
  assert.equal(row.message.length, 400);
});

test('unexpected crash returns a 500 with a ref and logs it', async () => {
  installFetch();
  const env = makeEnv(); const ctx = makeCtx();
  await consent(env, ctx);
  const bad = makeAI(); bad.run = async () => { throw new TypeError('kaboom'); };
  env.AI = bad; env.GEMINI_ENABLED = '0';
  const r = await call(env, ctx, tq({ rid: 'rec-qqqqqqqq' }), { method: 'POST', body: audio(), headers: { 'Content-Type': 'audio/webm' } });
  assert.equal(r.status, 502); // engine failure is reported as 502, not a crash
  env.DB.prepare = () => { throw new Error('db down'); };
  const crash = await worker.fetch(new Request('https://worker.example/api/config', { headers: { 'X-RZ-Access': 'secret-code', 'X-RZ-Client': 'client-test-0001' } }), env, ctx);
  assert.equal(crash.status, 500);
  const cj = await crash.json();
  assert.equal(cj.error, 'server_error');
});

test('timingSafeEqual', () => {
  assert.equal(T.timingSafeEqual('abc', 'abc'), true);
  assert.equal(T.timingSafeEqual('abc', 'abd'), false);
  assert.equal(T.timingSafeEqual('abc', 'abcd'), false);
});
