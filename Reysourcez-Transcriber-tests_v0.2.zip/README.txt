Reysourcez Voice Transcriber - tests (VERSION 0.2, 2026-10-08)
Put these three files in the folder that holds the v0.2 files (page, recorder, worker, nav-config.js, site-config.js)
plus your styles.css, then run (needs Node 22.5 or newer):

  node --test test-worker.mjs test-recorder.mjs        (51 checks, a few seconds)
  NODE_PATH=<folder with playwright> node e2e.mjs       (38 checks in a real headless Chromium with a fake microphone)

What they prove: the Worker's rules (consent, caps, engines, fixes, word list, delete), the page's helper code,
and the whole page talking to the real Worker code with pretend engines. They do NOT call Google or Cloudflare.
