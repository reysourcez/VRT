// End-to-end test: real Chromium (fake microphone) -> real page -> real Worker code (mock D1/engines)
// Run: NODE_PATH=/home/claude/.npm-global/lib/node_modules node e2e.mjs
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const { chromium } = require('playwright');

const ROOT = process.cwd();
const SITE = path.join(ROOT, 'site_test');
const SHOTS = path.join(ROOT, 'shots');
fs.rmSync(SITE, { recursive: true, force: true });
fs.mkdirSync(SITE, { recursive: true });
fs.mkdirSync(SHOTS, { recursive: true });

/* ---- build the test site: real files, only apiBase and segment length changed for testing ---- */
for (const f of ['Reysourcez-Transcriber-page_v0.2.html', 'Reysourcez-Transcriber-recorder_v0.2.js', 'nav-config.js']) fs.copyFileSync(path.join(ROOT, f), path.join(SITE, f));
fs.copyFileSync(path.join(ROOT, 'styles.css'), path.join(SITE, 'styles.css'));
let sc = fs.readFileSync(path.join(ROOT, 'site-config.js'), 'utf8');
sc = sc.replace('https://reysourcez-transcriber-worker.YOUR-SUBDOMAIN.workers.dev', 'http://localhost:8787').replace('segmentMinutes: 10,', 'segmentMinutes: 0.05,');
fs.writeFileSync(path.join(SITE, 'site-config.js'), sc);

/* ---- Worker under test ---- */
fs.writeFileSync('/tmp/worker_e2e.mjs', fs.readFileSync(path.join(ROOT, 'Reysourcez-Transcriber-worker_v0.2.js'), 'utf8'));
const worker = (await import('/tmp/worker_e2e.mjs')).default;

class Stmt {
  constructor(db, sql, params) { this.db = db; this.sql = sql; this.params = params || []; }
  bind(...p) { for (const v of p) if (v === undefined) throw new Error("D1_TYPE_ERROR: undefined"); return new Stmt(this.db, this.sql, p); }
  async first() { const r = this.db.prepare(this.sql).get(...this.params); return r ? { ...r } : null; }
  async all() { return { results: this.db.prepare(this.sql).all(...this.params).map((r) => ({ ...r })), success: true }; }
  async run() { const i = this.db.prepare(this.sql).run(...this.params); return { success: true, results: [], meta: { changes: Number(i.changes) } }; }
}
class D1Mock {
  constructor() { this.db = new DatabaseSync(':memory:'); }
  prepare(sql) { return new Stmt(this.db, sql, []); }
  async batch(stmts) { const out = []; this.db.exec('BEGIN'); try { for (const s of stmts) out.push(/^\s*select/i.test(s.sql) ? await s.all() : await s.run()); this.db.exec('COMMIT'); } catch (e) { this.db.exec('ROLLBACK'); throw e; } return out; }
}
const geminiLog = [];
globalThis.fetch = async (url, opts = {}) => {
  const u = String(url);
  const hd = {}; for (const [k, v] of Object.entries(opts.headers || {})) hd[k.toLowerCase()] = v;
  geminiLog.push({ url: u, method: opts.method || 'GET', headers: hd, size: opts.body && (opts.body.byteLength || opts.body.length) });
  if (u.endsWith('/upload/v1beta/files')) return new Response('{}', { status: 200, headers: { 'x-goog-upload-url': 'https://upload.example/up' } });
  if (u === 'https://upload.example/up') return new Response(JSON.stringify({ file: { name: 'files/x1', uri: 'https://g/files/x1', state: 'ACTIVE' } }), { status: 200 });
  if (u.includes(':generateContent')) return new Response(JSON.stringify({ candidates: [{ content: { parts: [{ text: 'selamat pagi semua teh' }] } }] }), { status: 200 });
  if ((opts.method || '') === 'DELETE') return new Response('{}', { status: 200 });
  return new Response('not mocked', { status: 599 });
};
const env = {
  DB: new D1Mock(),
  AI: { calls: [], async run(m, i) { this.calls.push({ m, i }); return { text: 'whisper kata hello', transcription_info: { language: 'ms' } }; } },
  AUDIO: { store: new Map(), async put(k, v) { this.store.set(k, v.byteLength); }, async delete(k) { this.store.delete(k); } },
  ACCESS_CODE: 'secret-code', GEMINI_API_KEY: 'gkey', GEMINI_ENABLED: '1', ALLOWED_ORIGINS: 'http://localhost:8000'
};
const pending = [];
const wctx = { waitUntil: (p) => pending.push(p) };

const api = http.createServer(async (req, res) => {
  const chunks = []; for await (const c of req) chunks.push(c);
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) if (!['host', 'connection', 'transfer-encoding'].includes(k)) headers.set(k, Array.isArray(v) ? v.join(',') : v);
  const body = chunks.length && !['GET', 'HEAD'].includes(req.method) ? Buffer.concat(chunks) : undefined;
  const r = await worker.fetch(new Request('http://localhost:8787' + req.url, { method: req.method, headers, body }), env, wctx);
  const out = {}; r.headers.forEach((v, k) => { out[k] = v; });
  res.writeHead(r.status, out); res.end(Buffer.from(await r.arrayBuffer()));
});
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
const site = http.createServer((req, res) => {
  const p = path.join(SITE, decodeURIComponent(new URL(req.url, 'http://x').pathname));
  if (!p.startsWith(SITE) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end('nope'); }
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(p)] || 'application/octet-stream' }); res.end(fs.readFileSync(p));
});
await new Promise((r) => api.listen(8787, r));
await new Promise((r) => site.listen(8000, r));

/* ---- tiny WAV (1 s, 440 Hz) for the upload test ---- */
function wav(sec) {
  const sr = 16000, n = sr * sec, buf = Buffer.alloc(44 + n * 2);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write('WAVEfmt ', 8); buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(sr, 24); buf.writeUInt32LE(sr * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34); buf.write('data', 36); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(Math.round(8000 * Math.sin(2 * Math.PI * 440 * i / sr)), 44 + i * 2);
  return buf;
}

let passed = 0, failed = 0;
function check(name, cond, extra) { if (cond) { passed++; console.log('  PASS', name); } else { failed++; console.log('  FAIL', name, extra !== undefined ? '=> ' + JSON.stringify(extra) : ''); } }

const browser = await chromium.launch({ args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'] });
const context = await browser.newContext({ viewport: { width: 1280, height: 1000 }, permissions: ['microphone'] });
const page = await context.newPage();
const problems = [];
page.on('pageerror', (e) => problems.push('pageerror: ' + e.message));
page.on('console', (m) => { if (m.type() === 'error' && !/fonts\.(googleapis|gstatic)|ERR_INTERNET|ERR_NAME_NOT_RESOLVED|ERR_CONNECTION|favicon|Failed to load resource/i.test(m.text())) problems.push('console: ' + m.text()); });
page.on('dialog', (d) => d.accept());

try {
  console.log('1. Page loads, nav and version');
  await page.goto('http://localhost:8000/Reysourcez-Transcriber-page_v0.2.html', { waitUntil: 'domcontentloaded' });
  await page.waitForFunction(() => document.querySelectorAll('.nav-dropdown-menu li').length > 0);
  check('title shows version', /v0\.2/.test(await page.title()));
  const navItems = await page.$$eval('.nav-dropdown-menu a', (as) => as.map((a) => ({ t: a.textContent, cur: a.getAttribute('aria-current') })));
  check('nav-config.js built the menu (16 items incl. Voice Transcriber)', navItems.length === 16 && navItems.some((a) => a.t === 'Voice Transcriber'), navItems.length);
  check('current page marked in the menu', navItems.some((a) => a.t === 'Voice Transcriber' && a.cur === 'page'));
  check('record button disabled before setup', await page.isDisabled('#rzt-rec'));
  check('status asks for the access code', /access code/i.test(await page.textContent('#rzt-status')), await page.textContent('#rzt-status'));

  console.log('2. Wrong code, then right code');
  await page.fill('#rzt-access', 'wrong');
  await page.click('#rzt-connect');
  await page.waitForFunction(() => /wrong|missing/i.test(document.getElementById('rzt-setup-msg').textContent));
  check('wrong code explained in plain words', /access code/i.test(await page.textContent('#rzt-setup-msg')), await page.textContent('#rzt-setup-msg'));
  await page.fill('#rzt-access', 'secret-code');
  await page.click('#rzt-connect');
  await page.waitForFunction(() => /^Connected\.?$/.test(document.getElementById('rzt-setup-msg').textContent));
  const chips = await page.textContent('#rzt-conn');
  check('chips show Worker v0.2, Gemini on, Whisper on', /Worker v0\.2/.test(chips) && /Gemini on/.test(chips) && /Whisper on/.test(chips), chips);
  const langs = await page.$$eval('#rzt-lang option', (os) => os.map((o) => o.value));
  check('language list from Worker', langs.includes('ms-sarawak') && langs.includes('iban') && langs.length === 8, langs);
  check('still locked until consent', await page.isDisabled('#rzt-rec'));

  console.log('3. Consent');
  await page.click('#rzt-c-save');
  await page.waitForFunction(() => /both required/i.test(document.getElementById('rzt-setup-msg').textContent));
  check('cannot continue without the two required boxes', await page.isDisabled('#rzt-rec'));
  await page.check('#rzt-c-processing'); await page.check('#rzt-c-participants'); await page.check('#rzt-c-keep');
  await page.click('#rzt-c-save');
  await page.waitForFunction(() => /Consent saved/.test(document.getElementById('rzt-c-status').textContent));
  check('record button enabled after consent', !(await page.isDisabled('#rzt-rec')));
  check('keep-audio option appears (R2 bound + consent)', await page.isVisible('#rzt-keep-wrap'));
  await page.screenshot({ path: path.join(SHOTS, 'desktop-ready.png'), fullPage: true });

  console.log('4. Record with the fake microphone, parts of 3 s');
  await page.selectOption('#rzt-lang', 'ms-sarawak');
  await page.fill('#rzt-title', 'E2E test meeting');
  await page.click('#rzt-rec');
  await page.waitForFunction(() => document.getElementById('rzt-rec').getAttribute('aria-pressed') === 'true');
  check('button turns into Stop', /Stop recording/.test(await page.textContent('#rzt-rec-label')));
  await page.waitForTimeout(7600);
  const timer = await page.textContent('#rzt-time');
  check('timer is running', /^00:0[5-9]$/.test(timer), timer);
  await page.screenshot({ path: path.join(SHOTS, 'desktop-recording.png'), fullPage: true });
  await page.click('#rzt-rec');
  await page.waitForFunction(() => document.querySelectorAll('.rzt-part textarea:not([hidden])').length >= 2, null, { timeout: 20000 });
  await page.waitForFunction(() => /All parts are transcribed/.test(document.getElementById('rzt-status').textContent), null, { timeout: 20000 });
  const texts = await page.$$eval('.rzt-part textarea:not([hidden])', (ts) => ts.map((t) => t.value));
  check('at least 2 parts, all transcribed', texts.length >= 2 && texts.every((t) => t === 'selamat pagi semua teh'), texts);
  const nParts = texts.length;
  const upl = geminiLog.filter((g) => g.url.endsWith('/upload/v1beta/files'));
  check('each part was sent to Gemini as audio/webm', upl.length === nParts && upl.every((g) => g.headers['x-goog-upload-header-content-type'] === 'audio/webm'), upl.map((g) => g.headers['x-goog-upload-header-content-type']));
  check('real audio bytes were uploaded', geminiLog.filter((g) => g.url === 'https://upload.example/up').every((g) => g.size > 1000), geminiLog.filter((g) => g.url === 'https://upload.example/up').map((g) => g.size));
  check('button back to Start, mic released', /Start recording/.test(await page.textContent('#rzt-rec-label')));
  const order = await page.$$eval('.rzt-part .rzt-part-head span:first-child', (s) => s.map((x) => x.textContent.split(',')[0]));
  check('parts shown in order', order.every((o, i) => o === 'Part ' + (i + 1)), order);
  await page.waitForTimeout(300);
  await page.screenshot({ path: path.join(SHOTS, 'desktop-transcript.png'), fullPage: true });

  console.log('5. Fix a word three times (three parts), add a new word to the list');
  let ruleMsg = '';
  for (let i = 0; i < 3; i++) {
    if (i >= nParts) break;
    const ta = (await page.$$('.rzt-part textarea:not([hidden])'))[i];
    await ta.fill('selamat pagi semua the Kuching');
    const btn = (await page.$$('.rzt-part button:has-text("Save corrections")'))[i];
    await btn.click();
    await page.waitForFunction((n) => /Saved/.test(document.querySelectorAll('.rzt-part-state')[n].textContent), i);
  }
  const chipTexts = await page.$$eval('.rzt-chip-btn', (b) => b.map((x) => x.textContent));
  check('new-word chips offered (Kuching)', chipTexts.includes('+ Kuching'), chipTexts);
  await page.click('.rzt-chip-btn:has-text("+ Kuching")');
  await page.waitForFunction(() => /Added: Kuching/.test(document.body.textContent));
  await page.click('summary:has-text("Word list")');
  await page.waitForFunction(() => [...document.querySelectorAll('#rzt-lex-list td')].some((td) => td.textContent === 'Kuching'));
  check('word appears in the word list', true);
  const sugText = await page.$$eval('.rzt-sug .rzt-msg', (m) => m.map((x) => x.textContent).join(' | '));
  if (nParts >= 3) check('repeated fix flagged on third sighting', /teh.*the.*seen 3/.test(sugText), sugText);
  else console.log('  (only ' + nParts + ' parts, skipping the third-sighting check)');

  console.log('6. Approve the fix, then upload a file in Compare mode');
  if (nParts >= 3) {
    await page.click('summary:has-text("Suggested fixes")');
    await page.waitForFunction(() => document.querySelectorAll('#rzt-rules-list li').length === 1);
    await page.click('#rzt-rules-list button:has-text("Approve")');
    await page.waitForFunction(() => document.querySelectorAll('#rzt-rules-list li').length === 0);
    check('rule approved (access code works as admin)', true);
  }
  await page.selectOption('#rzt-engine', 'both');
  await page.setInputFiles('#rzt-file', { name: 'clip.wav', mimeType: 'audio/wav', buffer: wav(2) });
  await page.waitForFunction(() => [...document.querySelectorAll('.rzt-engine-run')].length >= 2, null, { timeout: 20000 });
  const runs = await page.$$eval('.rzt-engine-run summary', (s) => s.map((x) => x.textContent));
  check('both engines shown', runs.length === 2 && runs.some((r) => /Gemini/.test(r)) && runs.some((r) => /Whisper/.test(r)), runs);
  const lastTa = (await page.$$('.rzt-part textarea:not([hidden])')).pop();
  const afterRule = await lastTa.inputValue();
  if (nParts >= 3) check('approved fix applied to the new transcript', afterRule === 'selamat pagi semua the', afterRule);
  check('Whisper got base64 audio and the language hint', env.AI.calls.length >= 1 && env.AI.calls[0].i.language === 'ms' && env.AI.calls[0].i.audio.length > 100, env.AI.calls[0] && Object.keys(env.AI.calls[0].i));
  await lastTa.fill('selamat pagi semua the hari ini');
  await page.locator('.rzt-part button:visible', { hasText: 'Score engines against my text' }).first().click();
  await page.waitForFunction(() => /Error rate against your text/.test(document.body.textContent), null, { timeout: 10000 });
  const scoreMsg = await page.$$eval('.rzt-part .rzt-msg.is-ok', (m) => m.map((x) => x.textContent).filter((t) => /Error rate/.test(t)).pop());
  check('score shows both engines as percentages', /Gemini: \d+\.\d%/.test(scoreMsg) && /Whisper \(Cloudflare\): \d+\.\d%/.test(scoreMsg), scoreMsg);
  await page.screenshot({ path: path.join(SHOTS, 'desktop-compare.png'), fullPage: true });

  console.log('7. Word list import, history, usage');
  await page.fill('#rzt-lex-term', 'TERM_TYPED'); await page.fill('#rzt-lex-meaning', 'typed in test');
  await page.click('#rzt-lex-add');
  await page.waitForFunction(() => [...document.querySelectorAll('#rzt-lex-list td')].some((td) => td.textContent === 'TERM_TYPED'));
  await page.setInputFiles('#rzt-lex-file', { name: 'words.csv', mimeType: 'text/csv', buffer: Buffer.from('language,term,meaning\nms-sarawak,CSV_ONE,one\nms-sarawak,CSV_TWO,two\nms-sarawak,EXAMPLE_TERM,skip me\n') });
  await page.waitForFunction(() => /Imported 2 words/.test(document.getElementById('rzt-lex-msg').textContent));
  check('CSV import: 2 words, example row skipped', true);
  await page.click('summary:has-text("History")');
  await page.click('#rzt-hist-refresh');
  await page.waitForFunction(() => document.querySelectorAll('#rzt-hist-list li').length >= 2);
  const hist = await page.$$eval('#rzt-hist-list li', (l) => l.map((x) => x.textContent));
  check('history lists the recordings', hist.length === 2 && hist.some((h) => /E2E test meeting/.test(h)), hist);
  await page.click('#rzt-hist-list li:first-child button:has-text("Delete")'); // newest = the uploaded clip
  await page.waitForFunction(() => document.querySelectorAll('#rzt-hist-list li').length === 1);
  check('delete removes it', true);
  await page.click('#rzt-hist-list li button:has-text("Open")');
  await page.waitForFunction(() => /Opened/.test(document.getElementById('rzt-status').textContent));
  check('open loads saved parts', (await page.$$('.rzt-part textarea:not([hidden])')).length === nParts);
  await page.click('summary:has-text("Usage and cost")');
  await page.click('#rzt-usage-refresh');
  await page.waitForFunction(() => /This device today/.test(document.getElementById('rzt-usage-out').textContent));
  check('usage text shows cap', /cap/.test(await page.textContent('#rzt-usage-out')), await page.textContent('#rzt-usage-out'));

  console.log('8. Download and copy');
  const [dl] = await Promise.all([page.waitForEvent('download'), page.click('#rzt-download')]);
  const dlText = fs.readFileSync(await dl.path(), 'utf8');
  check('download has header and parts', /^Voice Transcriber v0\.2/.test(dlText) && /\[Part 1, 00:00 to /.test(dlText), dlText.slice(0, 120));

  console.log('9. Diagnostics');
  await page.click('summary:has-text("Diagnostics")');
  await page.click('#rzt-diag-run');
  await page.waitForFunction(() => /Recent page events/.test(document.getElementById('rzt-diag-out').textContent));
  const diag = await page.textContent('#rzt-diag-out');
  check('diagnostics: secure page, recorder, Worker health, access ok', /\[ok\]\s+Secure page/.test(diag) && /\[ok\]\s+A usable format/.test(diag) && /\[ok\]\s+Worker health: OK/.test(diag) && /\[ok\]\s+Access code accepted/.test(diag), diag);
  check('diagnostics: no [FIX] items', !/\[FIX\]/.test(diag), diag.split('\n').filter((l) => /FIX/.test(l)));
  await page.screenshot({ path: path.join(SHOTS, 'desktop-panels.png'), fullPage: true });

  console.log('10. Phone-size layout');
  await page.setViewportSize({ width: 390, height: 844 });
  await page.waitForTimeout(200);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1);
  check('no sideways scrolling at 390 px', !overflow);
  await page.screenshot({ path: path.join(SHOTS, 'mobile.png'), fullPage: true });

  console.log('11. Page health');
  check('no JavaScript or console errors', problems.length === 0, problems);
  check('Worker error log is empty', env.DB.db.prepare('SELECT COUNT(*) AS n FROM error_log').get().n === 0, env.DB.db.prepare('SELECT * FROM error_log').all());
} catch (e) {
  failed++; console.log('  FAIL (exception)', e.message.split('\n').slice(0, 6).join(' | '));
  try { await page.screenshot({ path: path.join(SHOTS, 'failure.png'), fullPage: true }); } catch (e2) { /* ignore */ }
  console.log('  page problems so far:', problems);
  console.log('  status text:', await page.textContent('#rzt-status').catch(() => '?'));
}
await browser.close(); api.close(); site.close();
console.log('\nRESULT: ' + passed + ' passed, ' + failed + ' failed');
process.exit(failed ? 1 : 0);
