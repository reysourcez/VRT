// Unit tests for the pure helpers in Reysourcez-Transcriber-recorder_v0.2.js
// Run: node --test test-recorder.mjs
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const R = require('./Reysourcez-Transcriber-recorder_v0.2.js');

test('pickMime: first supported in preference order; empty when none', () => {
  assert.equal(R.pickMime((m) => m === 'audio/mp4'), 'audio/mp4');
  assert.equal(R.pickMime((m) => true), 'audio/webm;codecs=opus');
  assert.equal(R.pickMime((m) => m.startsWith('audio/mp4')), 'audio/mp4;codecs=mp4a.40.2');
  assert.equal(R.pickMime(() => false), '');
  assert.equal(R.pickMime(() => { throw new Error('x'); }), '');
});

test('mimeBase / fmtTime', () => {
  assert.equal(R.mimeBase('Audio/WebM;codecs=opus'), 'audio/webm');
  assert.equal(R.fmtTime(0), '00:00');
  assert.equal(R.fmtTime(65.9), '01:05');
  assert.equal(R.fmtTime(3600), '1:00:00');
  assert.equal(R.fmtTime(-5), '00:00');
  assert.equal(R.fmtTime(undefined), '00:00');
});

test('tokens: words, apostrophes, hyphens, digits; Chinese counted per character', () => {
  assert.deepEqual(R.tokens("Kita pergi ke Kuching, dak? It's 5-star."), ['Kita', 'pergi', 'ke', 'Kuching', 'dak', "It's", '5-star']);
  assert.deepEqual(R.tokens('\u4f60\u597d\u5417 hello'), ['\u4f60', '\u597d', '\u5417', 'hello']);
  assert.deepEqual(R.tokens(''), []);
  assert.deepEqual(R.tokens(null), []);
});

test('wer: exact, substitution, insertion, deletion, case and punctuation ignored', () => {
  assert.equal(R.wer('a b c d', 'a b c d').wer, 0);
  assert.equal(R.wer('a b c d', 'a b x d').wer, 0.25);
  assert.equal(R.wer('a b c d', 'a b c d e').wer, 0.25);
  assert.equal(R.wer('a b c d', 'a b d').wer, 0.25);
  assert.equal(R.wer('Hello, World!', 'hello world').wer, 0);
  assert.equal(R.wer('a b', 'x y z').errors, 3);
  assert.equal(R.wer('', '').wer, 0);
  assert.equal(R.wer('', 'a').wer, 1);
  assert.equal(R.wer('a b c', '').wer, 1);
  const s = R.wer('one two three four five six', 'one too three for five');
  assert.equal(s.refWords, 6);
  assert.equal(s.errors, 3);
});

test('wer: Mandarin is scored per character', () => {
  const s = R.wer('\u4f60\u597d\u5417\u670b\u53cb', '\u4f60\u597d\u5417\u660e\u53cb');
  assert.equal(s.refWords, 5);
  assert.equal(s.errors, 1);
  assert.ok(Math.abs(s.wer - 0.2) < 1e-9);
});

test('wer: large texts stay fast (1500 words, scattered errors)', () => {
  const ref = Array.from({ length: 1500 }, (_, i) => 'w' + (i % 97)).join(' ');
  const hyp = ref.split(' ').map((w, i) => (i % 10 === 0 ? 'zz' : w)).join(' ');
  const t0 = Date.now();
  const s = R.wer(ref, hyp);
  assert.equal(s.errors, 150);
  assert.ok(Date.now() - t0 < 500, 'took ' + (Date.now() - t0) + ' ms');
});

test('diffWords: one-for-one replacements and new words', () => {
  const d = R.diffWords('kami pergi ke teh pasar', 'kami pergi ke the pasar baru');
  assert.deepEqual(d.pairs, [{ w: 'teh', r: 'the' }]);
  assert.deepEqual(d.newWords, ['the', 'baru']);
});

test('diffWords: two separate fixes, case kept, same words give nothing', () => {
  const d = R.diffWords('Saya makan nasi di rumah mereka', 'Saya makan nasik di rumah kamek');
  assert.deepEqual(d.pairs, [{ w: 'nasi', r: 'nasik' }, { w: 'mereka', r: 'kamek' }]);
  assert.deepEqual(R.diffWords('a b c', 'a b c'), { pairs: [], newWords: [] });
  assert.deepEqual(R.diffWords('a b c', 'A B C'), { pairs: [], newWords: [] });
});

test('diffWords: deletions and insertions are not turned into replacements', () => {
  assert.deepEqual(R.diffWords('a b c d', 'a b d').pairs, []);
  assert.deepEqual(R.diffWords('a b d', 'a b c d').pairs, []);
  assert.deepEqual(R.diffWords('a b d', 'a b c d').newWords.length, 0, 'single letters are too short to suggest');
});

test('diffWords: short and numeric words are not suggested as new words', () => {
  const d = R.diffWords('hello there', 'hello there 2026 ok kuching');
  assert.deepEqual(d.newWords, ['kuching']);
});

test('diffWords: very large change does not hang', () => {
  const a = Array.from({ length: 2000 }, (_, i) => 'a' + i).join(' ');
  const b = Array.from({ length: 2000 }, (_, i) => 'b' + i).join(' ');
  const t0 = Date.now();
  const d = R.diffWords(a, b);
  assert.ok(Date.now() - t0 < 1500);
  assert.deepEqual(d.pairs, [], 'too different: rule extraction skipped');
});

test('parseCsv: quotes, commas, CRLF, BOM, blank lines', () => {
  const rows = R.parseCsv('\uFEFFlanguage,term,meaning\r\nms-sarawak,"a, b","say ""hi"""\r\n\r\niban,x,\r\n');
  assert.deepEqual(rows, [['language', 'term', 'meaning'], ['ms-sarawak', 'a, b', 'say "hi"'], ['iban', 'x', '']]);
  assert.deepEqual(R.parseCsv(''), []);
  assert.deepEqual(R.parseCsv('a,b'), [['a', 'b']]);
});

test('lexiconFromCsv: header mapping, example row skipped, errors', () => {
  const items = R.lexiconFromCsv('Term,Language,Source\nkamek,ms-sarawak,my notes\nEXAMPLE_TERM,ms-sarawak,x\n,iban,\nTERM2,iban,');
  assert.deepEqual(items, [
    { language: 'ms-sarawak', term: 'kamek', meaning: '', variants: '', source: 'my notes' },
    { language: 'iban', term: 'TERM2', meaning: '', variants: '', source: '' }
  ]);
  assert.throws(() => R.lexiconFromCsv('word,lang\na,b'), /header/);
  assert.throws(() => R.lexiconFromCsv(''), /empty/);
});

test('mimeFromName: trust audio types, fall back to the extension', () => {
  assert.equal(R.mimeFromName('x.m4a', ''), 'audio/m4a');
  assert.equal(R.mimeFromName('x.MP3', 'application/octet-stream'), 'audio/mpeg');
  assert.equal(R.mimeFromName('x.bin', ''), '');
  assert.equal(R.mimeFromName('x.wav', 'audio/wav'), 'audio/wav');
  assert.equal(R.mimeFromName('rec', 'audio/webm;codecs=opus'), 'audio/webm');
});

test('buildTxt: header and time ranges add up', () => {
  const t = R.buildTxt([{ idx: 0, dur: 600, text: 'one' }, { idx: 1, dur: 65, text: 'two' }], { language: 'English', date: '2026-10-08' });
  const lines = t.split('\n');
  assert.equal(lines[0], 'Voice Transcriber v0.2');
  assert.ok(t.includes('[Part 1, 00:00 to 10:00]\none'));
  assert.ok(t.includes('[Part 2, 10:00 to 11:05]\ntwo'));
});

test('retryable and friendlyError', () => {
  assert.equal(R.retryable({ code: 'network' }), true);
  assert.equal(R.retryable({ status: 503 }), true);
  assert.equal(R.retryable({ status: 429 }), false);
  assert.equal(R.retryable({ status: 502 }), false);
  assert.equal(R.retryable(null), false);
  assert.match(R.friendlyError({ code: 'bad_access_code', message: 'x' }), /access code/);
  assert.match(R.friendlyError({ code: 'consent_required', message: 'x' }), /consent/);
  assert.equal(R.friendlyError({ code: 'monthly_cap', message: 'Cap reached' }), 'Cap reached');
  assert.equal(R.friendlyError(null), 'Something went wrong.');
});

test('page settings fall back safely when site-config has no transcriber block', () => {
  assert.equal(R.CFG.segmentMinutes, 10);
  assert.equal(R.CFG.echoCancellation, false);
  assert.equal(R.CFG.consentVersion, '2026-10-v1');
});

test('diffWords: prefers the look-alike word (teh -> the), not the newly added word', () => {
  const d = R.diffWords('selamat pagi semua teh', 'selamat pagi semua the Kuching');
  assert.deepEqual(d.pairs, [{ w: 'teh', r: 'the' }]);
  assert.deepEqual(d.newWords, ['the', 'Kuching']);
  const d2 = R.diffWords('saya pergi ke pasar', 'saya pergi ke Kuching pasar baru');
  assert.deepEqual(d2.pairs, []);
});
